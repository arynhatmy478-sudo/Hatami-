plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "app.yptforest"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.yptforest"
        minSdk = 24
        targetSdk = 34
        versionCode = 8
        versionName = "4.1"
    }
    signingConfigs {
        create("release") {
            storeFile = file("release.keystore")
            storePassword = "focusforest"
            keyAlias = "focusforest"
            keyPassword = "focusforest"
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
