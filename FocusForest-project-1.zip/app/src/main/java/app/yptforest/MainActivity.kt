package app.yptforest

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.Context
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Base64
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var custom: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var pending: ByteArray? = null
    private var ring: Ringtone? = null

    private fun stopRing() {
        try { ring?.stop() } catch (_: Exception) {}
        ring = null
        try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (_: Exception) {}
    }

    override fun onDestroy() {
        stopRing()
        super.onDestroy()
    }

    // پل جاوااسکریپت: قفل صفحه (Android.lock / unlock) و ذخیره‌ی فایل (Android.saveFile)
    inner class Bridge {
        @JavascriptInterface
        fun lock() = runOnUiThread {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            try { startLockTask() } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun unlock() = runOnUiThread {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            try { stopLockTask() } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun alarm() = runOnUiThread {
            stopRing()
            try {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val r = RingtoneManager.getRingtone(this@MainActivity, uri)
                r.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
                r.play()
                ring = r
            } catch (_: Exception) {}
            try {
                val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                val pat = longArrayOf(0, 600, 300, 600, 300, 600, 1200)
                if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createWaveform(pat, -1))
                else @Suppress("DEPRECATION") vib.vibrate(pat, -1)
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun stopAlarm() = runOnUiThread { stopRing() }

        @JavascriptInterface
        fun saveFile(name: String, mime: String, b64: String) {
            pending = Base64.decode(b64, Base64.DEFAULT)
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
                        .addCategory(Intent.CATEGORY_OPENABLE)
                        .setType(mime)
                        .putExtra(Intent.EXTRA_TITLE, name)
                    startActivityForResult(i, 8)
                } catch (e: Exception) {
                    pending = null
                }
            }
        }
    }

    private val chrome = object : WebChromeClient() {
        override fun onShowFileChooser(
            v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
        ): Boolean {
            fileCb?.onReceiveValue(null)
            fileCb = cb
            return try {
                startActivityForResult(p.createIntent(), 7); true
            } catch (e: Exception) {
                fileCb = null; false
            }
        }

        override fun onShowCustomView(v: View, c: CustomViewCallback) {
            if (custom != null) { c.onCustomViewHidden(); return }
            custom = v; customCb = c
            root.addView(v, FrameLayout.LayoutParams(-1, -1))
            web.visibility = View.GONE
        }

        override fun onHideCustomView() {
            custom?.let { root.removeView(it) }
            custom = null
            customCb?.onCustomViewHidden()
            web.visibility = View.VISIBLE
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = FrameLayout(this)
        web = WebView(this)
        web.setBackgroundColor(0xFF0F2A2E.toInt())
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }
        web.webChromeClient = chrome
        web.addJavascriptInterface(Bridge(), "Android")
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        when (rq) {
            7 -> {
                fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d))
                fileCb = null
            }
            8 -> {
                val u = d?.data
                val bytes = pending
                pending = null
                if (rs == RESULT_OK && u != null && bytes != null) {
                    val ok = try {
                        contentResolver.openOutputStream(u)?.use { it.write(bytes) }
                        true
                    } catch (e: Exception) { false }
                    val msg = if (ok) "ذخیره شد" else "ذخیره نشد"
                    web.evaluateJavascript("toast('$msg')", null)
                }
            }
            else -> super.onActivityResult(rq, rs, d)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (custom != null) { chrome.onHideCustomView(); return }
        web.evaluateJavascript("(window.__back?window.__back():false)") { r ->
            if (r != "true") finish()
        }
    }
}
